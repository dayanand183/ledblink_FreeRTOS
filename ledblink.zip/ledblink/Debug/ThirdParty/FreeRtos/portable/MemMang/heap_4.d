ThirdParty/FreeRtos/portable/MemMang/heap_4.o: \
 ../ThirdParty/FreeRtos/portable/MemMang/heap_4.c \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/FreeRTOS.h \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/FreeRTOSConfig.h \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/projdefs.h \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/portable.h \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/deprecated_definitions.h \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F/portmacro.h \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/mpu_wrappers.h \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/task.h \
 D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/list.h

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/FreeRTOS.h:

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/FreeRTOSConfig.h:

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/projdefs.h:

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/portable.h:

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/deprecated_definitions.h:

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F/portmacro.h:

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/mpu_wrappers.h:

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/task.h:

D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include/list.h:
