################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ThirdParty/FreeRtos/portable/MemMang/heap_4.c 

OBJS += \
./ThirdParty/FreeRtos/portable/MemMang/heap_4.o 

C_DEPS += \
./ThirdParty/FreeRtos/portable/MemMang/heap_4.d 


# Each subdirectory must supply rules for building sources it contributes
ThirdParty/FreeRtos/portable/MemMang/heap_4.o: ../ThirdParty/FreeRtos/portable/MemMang/heap_4.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32F446xx -DDEBUG -c -I../Drivers/CMSIS/Include -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Core/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"ThirdParty/FreeRtos/portable/MemMang/heap_4.d" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

