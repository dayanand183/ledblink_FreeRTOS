################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ThirdParty/FreeRtos/croutine.c \
../ThirdParty/FreeRtos/event_groups.c \
../ThirdParty/FreeRtos/list.c \
../ThirdParty/FreeRtos/queue.c \
../ThirdParty/FreeRtos/stream_buffer.c \
../ThirdParty/FreeRtos/tasks.c \
../ThirdParty/FreeRtos/timers.c 

OBJS += \
./ThirdParty/FreeRtos/croutine.o \
./ThirdParty/FreeRtos/event_groups.o \
./ThirdParty/FreeRtos/list.o \
./ThirdParty/FreeRtos/queue.o \
./ThirdParty/FreeRtos/stream_buffer.o \
./ThirdParty/FreeRtos/tasks.o \
./ThirdParty/FreeRtos/timers.o 

C_DEPS += \
./ThirdParty/FreeRtos/croutine.d \
./ThirdParty/FreeRtos/event_groups.d \
./ThirdParty/FreeRtos/list.d \
./ThirdParty/FreeRtos/queue.d \
./ThirdParty/FreeRtos/stream_buffer.d \
./ThirdParty/FreeRtos/tasks.d \
./ThirdParty/FreeRtos/timers.d 


# Each subdirectory must supply rules for building sources it contributes
ThirdParty/FreeRtos/croutine.o: ../ThirdParty/FreeRtos/croutine.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32F446xx -DDEBUG -c -I../Drivers/CMSIS/Include -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Core/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"ThirdParty/FreeRtos/croutine.d" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
ThirdParty/FreeRtos/event_groups.o: ../ThirdParty/FreeRtos/event_groups.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32F446xx -DDEBUG -c -I../Drivers/CMSIS/Include -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Core/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"ThirdParty/FreeRtos/event_groups.d" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
ThirdParty/FreeRtos/list.o: ../ThirdParty/FreeRtos/list.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32F446xx -DDEBUG -c -I../Drivers/CMSIS/Include -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Core/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"ThirdParty/FreeRtos/list.d" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
ThirdParty/FreeRtos/queue.o: ../ThirdParty/FreeRtos/queue.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32F446xx -DDEBUG -c -I../Drivers/CMSIS/Include -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Core/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"ThirdParty/FreeRtos/queue.d" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
ThirdParty/FreeRtos/stream_buffer.o: ../ThirdParty/FreeRtos/stream_buffer.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32F446xx -DDEBUG -c -I../Drivers/CMSIS/Include -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Core/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"ThirdParty/FreeRtos/stream_buffer.d" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
ThirdParty/FreeRtos/tasks.o: ../ThirdParty/FreeRtos/tasks.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32F446xx -DDEBUG -c -I../Drivers/CMSIS/Include -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Core/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"ThirdParty/FreeRtos/tasks.d" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
ThirdParty/FreeRtos/timers.o: ../ThirdParty/FreeRtos/timers.c
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DUSE_HAL_DRIVER -DSTM32F446xx -DDEBUG -c -I../Drivers/CMSIS/Include -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/include" -I"D:/Controllers/2026/STM32/FreeRtos/LedBlink/ledblink/ThirdParty/FreeRtos/portable/GCC/ARM_CM4F" -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Core/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"ThirdParty/FreeRtos/timers.d" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

